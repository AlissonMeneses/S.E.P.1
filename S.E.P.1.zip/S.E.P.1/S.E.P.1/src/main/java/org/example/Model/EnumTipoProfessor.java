package org.example.Model;

public class EnumTipoProfessor {

}
