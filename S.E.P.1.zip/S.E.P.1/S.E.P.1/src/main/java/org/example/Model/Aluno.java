package org.example.Model;

public class Aluno {
    private String matricula;
}
