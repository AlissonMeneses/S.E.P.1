package org.example.Model;

public class Professor {
    private String matricula;
    private TipoProfessor tipoProfessor;
}
