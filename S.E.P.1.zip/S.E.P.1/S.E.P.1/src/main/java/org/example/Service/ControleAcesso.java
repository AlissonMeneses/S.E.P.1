package org.example.Service;

public class ControleAcesso {
    @Autowired
    private PessoaRepository pessoaRepository;

    @Autowired
    private SalaRepository salaRepository;

    public void registrarEntrada(Pessoa pessoa, Long salaId) throws Exception {
        Sala sala = salaRepository.findById(salaId).orElseThrow(() -> new Exception("Sala não encontrada"));

        if (pessoa instanceof Visitante) {
            throw new Exception("Visitantes não podem entrar em salas.");
        } else if (pessoa instanceof Aluno && !sala.isAberta()) {
            throw new Exception("Aluno só pode entrar em sala aberta.");
        } else if (pessoa instanceof Professor) {
            Professor professor = (Professor) pessoa;
            if (professor.getTipoProfessor() == TipoProfessor.TEORICO && !(sala instanceof Laboratorio)) {
                sala.setAberta(true);
            } else if (professor.getTipoProfessor() == TipoProfessor.PRATICO) {
                sala.setAberta(true);
            } else {
                throw new Exception("Professor teórico não pode abrir laboratório.");
            }
        }

        sala.getPessoasPresentes().add(pessoa);
        pessoa.setDataEntrada(LocalDateTime.now());
        salaRepository.save(sala);
        pessoaRepository.save(pessoa);
    }

    public void registrarSaida(Pessoa pessoa, Long salaId) throws Exception {
        Sala sala = salaRepository.findById(salaId).orElseThrow(() -> new Exception("Sala não encontrada"));
        sala.getPessoasPresentes().remove(pessoa);
        pessoa.setDataSaida(LocalDateTime.now());
        salaRepository.save(sala);
        pessoaRepository.save(pessoa);
    }

    public List<Pessoa> listarPessoasPresentes(Long salaId) throws Exception {
        Sala sala = salaRepository.findById(salaId).orElseThrow(() -> new Exception("Sala não encontrada"));
        return sala.getPessoasPresentes();
    }

    public List<Equipamento> listarEquipamentos(Long salaId) throws Exception {
        Sala sala = salaRepository.findById(salaId).orElseThrow(() -> new Exception("Sala não encontrada"));
        return sala.getEquipamentos();
    }

    public List<Pessoa> listarPessoasNaEscola() {
        return pessoaRepository.findAll();
    }

    public Map<String, Long> contarPessoasPorTipo() {
        long visitantes = pessoaRepository.countByType(Visitante.class);
        long alunos = pessoaRepository.countByType(Aluno.class);
        long professoresTeoricos = pessoaRepository.countByTypeAndProfessorType(Professor.class, TipoProfessor.TEORICO);
        long professoresPraticos = pessoaRepository.countByTypeAndProfessorType(Professor.class, TipoProfessor.PRATICO);

        Map<String, Long> contagem = new HashMap<>();
        contagem.put("Visitantes", visitantes);
        contagem.put("Alunos", alunos);
        contagem.put("Professores Teóricos", professoresTeoricos);
        contagem.put("Professores Práticos", professoresPraticos);
        return contagem;
    }

    public void alterarSituacaoEquipamento(Long patrimonioId, Situacao situacao) throws Exception {
        Equipamento equipamento = equipamentoRepository.findById(patrimonioId).orElseThrow(() -> new Exception("Equipamento não encontrado"));
        equipamento.setSituacao(situacao);
        equipamentoRepository.save(equipamento);
    }

    public List<Equipamento> listarEquipamentosLigados() {
        return equipamentoRepository.findBySituacao(Situacao.LIGADO);
    }

    public void incluirEquipamento(Long salaId, Equipamento equipamento) throws Exception {
        Sala sala = salaRepository.findById(salaId).orElseThrow(() -> new Exception("Sala não encontrada"));
        sala.getEquipamentos().add(equipamento);
        salaRepository.save(sala);
    }

    public void removerEquipamento(Long salaId, Long equipamentoId) throws Exception {
        Sala sala = salaRepository.findById(salaId).orElseThrow(() -> new Exception("Sala não encontrada"));
        Equipamento equipamento = equipamentoRepository.findById(equipamentoId).orElseThrow(() -> new Exception("Equipamento não encontrado"));
        sala.getEquipamentos().remove(equipamento);
        salaRepository.save(sala);
    }
}
