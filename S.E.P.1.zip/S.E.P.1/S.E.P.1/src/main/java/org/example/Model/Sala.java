package org.example.Model;

public class Sala {
    private Long id;
    private String numero;
    private String bloco;
    private String apelido;
    private boolean aberta = false;
    private List<Equipamento> equipamentos;
    private List<Pessoa> pessoasPresentes;
}
