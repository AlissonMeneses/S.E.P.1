package org.example.Repository;

public class PessoaRepositorio {
    public interface PessoaRepository extends JpaRepository<Pessoa, Long> {}
}
