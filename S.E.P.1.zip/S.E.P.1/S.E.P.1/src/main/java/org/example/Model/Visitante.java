package org.example.Model;

public class Visitante {
    private Long id;
    private String nome;
    private String cpf;
    private LocalDateTime dataEntrada;
    private LocalDateTime dataSaida;
}
