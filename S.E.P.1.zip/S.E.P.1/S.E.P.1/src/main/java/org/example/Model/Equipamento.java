package org.example.Model;

public class Equipamento {
    private Long id;
    private String nome;
    private String numeroPatrimonio;
    private int anoAquisicao;
    private String descricao;
    private Situacao situacao;
    private boolean eletrico;
}
