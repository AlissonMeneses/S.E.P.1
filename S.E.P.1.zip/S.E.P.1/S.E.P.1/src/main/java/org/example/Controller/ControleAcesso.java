package org.example.Controller;

public class ControleAcesso {
    @Autowired
    private ControleAcessoService controleAcessoService;

    @PostMapping("/registrarEntrada")
    public ResponseEntity<String> registrarEntrada(@RequestBody Pessoa pessoa, @RequestParam Long salaId) {
        try {
            controleAcessoService.registrarEntrada(pessoa, salaId);
            return ResponseEntity.ok("Entrada registrada com sucesso");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/registrarSaida")
    public ResponseEntity<String> registrarSaida(@RequestBody Pessoa pessoa, @RequestParam Long salaId) {
        try {
            controleAcessoService.registrarSaida(pessoa, salaId);
            return ResponseEntity.ok("Saída registrada com sucesso");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/pessoasPresentes")
    public ResponseEntity<List<Pessoa>> listarPessoasPresentes(@RequestParam Long salaId) {
        try {
            return ResponseEntity.ok(controleAcessoService.listarPessoasPresentes(salaId));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/equipamentos")
    public ResponseEntity<List<Equipamento>> listarEquipamentos(@RequestParam Long salaId) {
        try {
            return ResponseEntity.ok(controleAcessoService.listarEquipamentos(salaId));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/pessoasNaEscola")
    public ResponseEntity<List<Pessoa>> listarPessoasNaEscola() {
        return ResponseEntity.ok(controleAcessoService.listarPessoasNaEscola());
    }

    @GetMapping("/contarPessoasPorTipo")
    public ResponseEntity<Map<String, Long>> contarPessoasPorTipo() {
        return ResponseEntity.ok(controleAcessoService.contarPessoasPorTipo());
    }

    @GetMapping("/equipamentosLigados")
    public ResponseEntity<List<Equipamento>> listarEquipamentosLigados() {
        return ResponseEntity.ok(controleAcessoService.listarEquipamentosLigados());
    }

    @PostMapping("/alterarSituacaoEquipamento")
    public ResponseEntity<String> alterarSituacaoEquipamento(@RequestParam Long patrimonioId, @RequestParam Situacao situacao) {
        try {
            controleAcessoService.alterarSituacaoEquipamento(patrimonioId, situacao);
            return ResponseEntity.ok("Situação do equipamento alterada com sucesso");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/incluirEquipamento")
    public ResponseEntity<String> incluirEquipamento(@RequestParam Long salaId, @RequestBody Equipamento equipamento) {
        try {
            controleAcessoService.incluirEquipamento(salaId, equipamento);
            return ResponseEntity.ok("Equipamento incluído com sucesso");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/removerEquipamento")
    public ResponseEntity<String> removerEquipamento(@RequestParam Long salaId, @RequestParam Long equipamentoId) {
        try {
            controleAcessoService.removerEquipamento(salaId, equipamentoId);
            return ResponseEntity.ok("Equipamento removido com sucesso");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
