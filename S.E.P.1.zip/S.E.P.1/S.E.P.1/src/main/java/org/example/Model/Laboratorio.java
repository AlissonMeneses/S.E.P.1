package org.example.Model;

public class Laboratorio {
    private List<Equipamento> equipamentosExtras;
}
