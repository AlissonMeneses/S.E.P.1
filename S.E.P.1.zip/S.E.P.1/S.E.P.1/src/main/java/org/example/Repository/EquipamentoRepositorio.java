package org.example.Repository;

public class EquipamentoRepositorio {
    public interface EquipamentoRepository extends JpaRepository<Equipamento, Long> {}
}
