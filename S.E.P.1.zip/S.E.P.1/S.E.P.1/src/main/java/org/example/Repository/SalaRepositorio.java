package org.example.Repository;

public class SalaRepositorio {
    public interface SalaRepository extends JpaRepository<Sala, Long> {}
}
